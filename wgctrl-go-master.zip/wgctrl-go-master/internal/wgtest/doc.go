// Package wgtest contains shared testing utilities for package wgctrl.
package wgtest
