// Package wgh is an auto-generated package which contains constants and
// types used to access WireGuard information using ioctl calls.
package wgh
