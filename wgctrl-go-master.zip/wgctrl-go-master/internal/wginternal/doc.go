// Package wginternal contains shared internal types for wgctrl.
//
// This package is internal-only and not meant for end users to consume.
// Please use package wgctrl (an abstraction over this package) instead.
package wginternal
