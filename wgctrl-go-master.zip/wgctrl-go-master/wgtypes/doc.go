// Package wgtypes provides shared types for the wgctrl family of packages.
package wgtypes // import "golang.zx2c4.com/wireguard/wgctrl/wgtypes"
